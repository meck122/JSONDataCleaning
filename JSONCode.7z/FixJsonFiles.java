import java.io.File; // walking down directory tree
import java.io.FileReader;
import java.io.IOException; // IOExceptions
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.Scanner; // user input

import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

public class FixJsonFiles {

	public static void main(String[] args) {

		// user input scanner for directory or file path
		Scanner user_input = new Scanner(System.in);
		String pathDirectory;
		System.out.print("Directory or File Path: ");
		pathDirectory = user_input.nextLine(); // sets path to user input

		user_input.close(); // close scanner

		File[] files = new File(pathDirectory).listFiles(); // array of
															// Files/Folders
															// within directory
		showJSONFiles(files, pathDirectory); // walk down directory tree

	}

	public static void editJSON(String pathOfFile) {

		System.out.print("\n" + pathOfFile); // prints path of current file

		if (!isJSONValid(pathOfFile)) {
			System.out.print(" NOT VALID");

			Path path = Paths.get(pathOfFile); // creates path object
			// File file = path.toFile(); // creates file object

			// fixing errors
			try {
				// sets charset
				Charset charset = StandardCharsets.UTF_8;

				// sets content string to whole text file
				String content = new String(Files.readAllBytes(path), charset);

				// fixes end brackets
				if (content.indexOf("]", content.length() - 2) != content.length() - 2) {

					Files.write(path, "]}".getBytes(), StandardOpenOption.APPEND); // appends

					System.out.print(" edited (brackets)\n"); // prints edit
				}

				// fixes ": ?"
				if (content.contains(": ?")) {

					content = content.replaceAll(": \\?", ": -1"); // replaces
																	// with -1
					Files.write(path, content.getBytes(charset)); // writes

					System.out.print(" edited (question marks)\n");
				}

				// fixes "EnergyAnnualAnalysis":
				if (content.contains("\"EnergyAnnualAnalysis\": }")) {

					// replaces with null
					content = content.replaceAll("\"EnergyAnnualAnalysis\": }", "\"EnergyAnnualAnalysis\": null}");

					Files.write(path, content.getBytes(charset)); // writes

					System.out.print(" edited \"EnergyAnnualAnalysis\": \n");
				}

			} catch (IOException e) {
				System.out.print(e);
			}

		} else {
			System.out.print(" VALID"); // prints valid if valid
		}
	}

	// checks if JSON is already valid
	public static boolean isJSONValid(String pathOfFile) {
		try {
			FileReader reader = new FileReader(pathOfFile);
			new JSONParser().parse(reader);
		} catch (IOException | ParseException e) {
			return false;
		}
		return true;
	}

	// walks down directory tree
	public static void showJSONFiles(File[] files, String path) {
		// try/catch confirms if it is a DIRECTORY path
		try {
			for (File file : files) {
				if (file.isDirectory()) {
					showJSONFiles(file.listFiles(), path); // Calls same method
															// again.
				} else {
					if (file.getName().contains(".json")) { // Finds JSON files.
						editJSON(file.getAbsolutePath()); // Edit file.
					}
				}
			}
		} catch (Exception e) { // Runs when path is NOT a DIRECTORY path.
			editJSON(path);
		}
	}

}
